# Modernizr-min
Minified version of [Modernizr](http://modernizr.com).
